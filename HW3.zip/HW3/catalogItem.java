public class catalogItem 
{
    //declaring instance variables
    private String title;
    private double price;

    //declaring constructor
    public catalogItem (String title, double price)
    {
        this. title = title;
        this.price = price;
    }

    //declaring getter methods
    public String getTheTitle()
    {
        return title;
    }

    public double getThePrice()
    {
        return price;
    }
}
