public class audioBook extends Book
{
    //declaring instance variables
    private double runningTime;

    //declaring constructor

    public audioBook (String title, double price, String author, int ISBN, double runningTime)
    {
        super (title, price, author, ISBN);

        this.runningTime = runningTime;
    }

    //declaring getter methods

    public double getTheRunningTime()
    {
        return runningTime;
    }

    //calculating 10% discount for audio books

    @Override 

    public double getThePrice()
    {
        return super.getThePrice() * 0.9;
    }

    //declaring toString method

    @Override 

    public String toString()
    {
        return "The title of the audio book is: " + getTheTitle() + "\nPrice $ : " + getThePrice() + 
        "\nAuthor : " + getTheAuthor() + "\nISBN : " + getTheISBN() + "\nRunning Time : " + getTheRunningTime();
    }
}
