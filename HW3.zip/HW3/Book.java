public class Book extends catalogItem
{
        //declaring instance variables
        private String author;
        private int ISBN;

        //declaring constructor

        public Book (String title, double price, String author, int ISBN)
        {
            super (title, price);

            this.author = author;
            this.ISBN = ISBN;
        }

        //declaring getter methods
        public String getTheAuthor()
        {
            return author;

        }

        public int getTheISBN()
        {
            return ISBN;
        }

        //declaring toString method

        @Override 

        public String toString()
        {
            return "The title of the book is: " + getTheTitle() + "\nPrice $ : " + getThePrice() + 
            "\nAuthor : " + getTheAuthor() + "\nISBN : " + getTheISBN();
        }
}
