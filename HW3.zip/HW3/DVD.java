public class DVD extends catalogItem
{
   //declaring instance variables

   private String director;
   private int year;
   private int dvdcode;

   //declaring constructor

   public DVD (String title, double price, String director, int year, int dvdcode)
   {
     super (title, price);

     this.director = director;
     this.year = year;
     this.dvdcode = dvdcode;
   }

   //declaring getter methods

   public String getTheDirector()
   {
       return director;
   }

   public int getTheYear()
   {
       return year;
   }

   public int getTheDvdCode()

   {
       return dvdcode;
   }

   //declaring toString method

   @Override 

   public String toString()
   {
    return "The title of the DVD is: " + getTheTitle() + "\nPrice $ : " + getThePrice() + 
    "\nDirector : " + getTheDirector() + "\nYear : " + getTheYear() + "\nDVD Code : " + getTheDvdCode();
   }
}
