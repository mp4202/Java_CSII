//Name: Monan Paul
//Date: 10/26/2026
//Instructor: Dr. Ranreng Feng
//Purpose: Develop a program for an online store which sells dvds and books (items). The store will have a cart which will contain the items the user wants to purchase and their prices.

import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.FileWriter;

public class HW3
{
        
    //scanner for user input 

        private static Scanner userInput = new Scanner (System.in);
       

        //declaring array list to store catalog items
        private static ArrayList <Book> bookList = new ArrayList <Book>();

        private static ArrayList <DVD> dvdList = new ArrayList <DVD>();



        //declaring the name of the file to store the catalog items

        private static String fileName = "catalog.txt";
        

    public static void main(String [] args)
    {
         
        
        
        //loading catalog items from the file

        try
        {
            File file = new File ("catalog.txt");
            
            //check if the file exists

            if (file.exists())
            {
                Scanner fileScanner = new Scanner (file);

                String categoryString = " ";

                while (fileScanner.hasNextLine())
                {
                    String line = fileScanner.nextLine();

                    //if line is empty, continue

                    if (line.isEmpty())
                    {
                        continue;
                    }

                    //if line is equal to Book, audiobook, or dvd set categoryString to Book
                    
                    if (line.equals ("Book") || line.equals("Audiobook") || line.equals("DVD"))
                    {
                        categoryString = line;
                        continue;
                    }

                    //declare 1D array to declare .split the line by comma

                    String[] data =   line.split(",");


                    //checking if the category is Book and the data length is 4, then create a new book object and add it to the bookList
                    try 

                    {
                        
                        if (categoryString.equals ("Book") && data.length == 4)
                        {
                             String title = data[0];
                             String author = data[1].trim();
                            double price = Double.parseDouble(data[2].trim());
                            int ISBN = Integer.parseInt(data[3].trim());

                            //checking if the ISBN already exists in the bookList, if not add the book to the list
                            if (!isbnExists(ISBN))
                            {
                                Book book = new Book (title, price, author, ISBN);
                                bookList.add(book);
                            }
                            else
                            {
                                System.out.println("Duplicate ISBN found for book: " + title + ". Skipping this entry.");
                            }
                        }

                        else if (categoryString.equals ("Audiobook") && data.length == 5)
                        {
                            String title = data[0];
                            String author = data[1].trim();
                            double price = Double.parseDouble(data[2].trim());
                            int ISBN = Integer.parseInt(data[3].trim());
                            double runningTime = Double.parseDouble(data[4].trim());

                            //checking if the ISBN already exists in the bookList, if not add the audiobook to the list
                            if (!isbnExists(ISBN))
                            {
                                audioBook audiobook = new audioBook (title, price, author, ISBN, runningTime);
                                bookList.add(audiobook);
                            }
                            else
                            {
                                System.out.println("Duplicate ISBN found for audiobook: " + title + ". Skipping this entry.");
                            }
                        }

                        else if (categoryString.equals ("DVD") && data.length == 5)
                        {
                            String title = data[0];
                            double price = Double.parseDouble(data[1].trim());
                            String director = data[2].trim();
                            int year = Integer.parseInt(data[3].trim());
                            int dvdcode = Integer.parseInt(data[4].trim());

                            //checking if the DVD code already exists in the dvdList, if not add the DVD to the list
                            if (!dvdCodeExists(dvdcode))
                            {
                                DVD dvd = new DVD (title, price, director, year, dvdcode);
                                dvdList.add(dvd);
                            }
                            else
                            {
                                System.out.println("Duplicate DVD code found for DVD: " + title + ". Skipping this entry.");
                            }
                        }
                        
                    }
                    catch (NumberFormatException e)
                    {
                        System.out.println("Error parsing number for line: " + line + ". Skipping this entry.");
                    }



                }

                //close the file scanner
                fileScanner.close();

                System.out.println("Catalog items loaded successfully from " + fileName);
            }
        
        }
        catch (FileNotFoundException e)
        {
            System.out.println("Error loading catalog items from file: " + e.getMessage());
        }

    //display menu to ask user if they want to add a book, audiobook, or dvd to the catalog

    System.out.println(" Welcome to the Catalog Managment Service!");
    System.out.println("Please select an option from the menu below:");
    System.out.println("1. Add a Book");
    System.out.println("2. Add an Audiobook");
    System.out.println("3. Add a DVD");
    System.out.println("4. Remove a Book");
    System.out.println("5. Remove an Audiobook");
    System.out.println("6. Display Catalog");
    System.out.println("9. Exit");

    //user input for menu section and validation to keep as loop

    int userChoice = 0;
    
    while (userChoice != 9)
    {
        System.out.print("Please Enter your choice: ");
        userChoice = userInput.nextInt();
        userInput.nextLine(); // newline character

        if (userChoice == 1)
        {
            //add book
            addBook();
            

            //after they add, display the menu in case if they would like to try or exit

            System.out.println ("Thank you for adding a book to the catalog!");
            System.out.println("Please select an option from the menu below:");
            System.out.println("1. Add a Book");
            System.out.println("2. Add an Audiobook");
            System.out.println("3. Add a DVD");
            System.out.println("4. Remove a Book");
            System.out.println("5. Remove an Audiobook");
            System.out.println("6. Display Catalog");
            System.out.println("9. Exit");
        }
        else if (userChoice == 2)
        {
            //add an audiobook
            addAudioBook();

            //after they add, display the menu in case if they would like to try or exit
            System.out.println ("Thank you for adding an audiobook to the catalog!");
            System.out.println("Please select an option from the menu below:");
            System.out.println("1. Add a Book");
            System.out.println("2. Add an Audiobook");
            System.out.println("3. Add a DVD");
            System.out.println("4. Remove a Book");
            System.out.println("5. Remove an Audiobook");
            System.out.println("6. Display Catalog");
            System.out.println("9. Exit");
        }
        else if (userChoice == 3)
        {
            //add a dvd
            addDVD();

            //after they add, display the menu in case if they would like to try or exit
            System.out.println ("Thank you for adding a DVD to the catalog!");
            System.out.println("Please select an option from the menu below:");
            System.out.println("1. Add a Book");
            System.out.println("2. Add an Audiobook");  
            System.out.println("3. Add a DVD");
            System.out.println("4. Remove a Book");
            System.out.println("5. Remove an Audiobook");
            System.out.println("6. Display Catalog");
            System.out.println("9. Exit");
        }
        else if (userChoice == 4)
        {
            //remove a book
            removeBook();

            //after they remove, display the menu in case if they would like to try or exit
            System.out.println ("Thank you for removing a book from the catalog!");
            System.out.println("Please select an option from the menu below:");
            System.out.println("1. Add a Book");
            System.out.println("2. Add an Audiobook");
            System.out.println("3. Add a DVD");
            System.out.println("4. Remove a Book");
            System.out.println("5. Remove an Audiobook");
            System.out.println("6. Display Catalog");
            System.out.println("9. Exit");
        }
        else if (userChoice == 5)
        {
            //remove an audiobook
            removeAudioBook();

            //after they remove, display the menu in case if they would like to try or exit
            System.out.println ("Thank you for removing an audiobook from the catalog!");
            System.out.println("Please select an option from the menu below:");
            System.out.println("1. Add a Book");
            System.out.println("2. Add an Audiobook");
            System.out.println("3. Add a DVD");
            System.out.println("4. Remove a Book");
            System.out.println("5. Remove an Audiobook");
            System.out.println("6. Display Catalog");
            System.out.println("9. Exit");
        }
        else if (userChoice == 6)
        {
            //display catalog
            displayCatalog();

            //after they display, display the menu in case if they would like to try or exit
        }
        else if (userChoice == 9)
        {
            //exit the program
            System.out.println("Thank you for using the Catalog service!");
            break;
        }

        //if the user enter an invalid choice, display an error message and ask the user to try again and display the entire menu

        else if  (userChoice != 1 && userChoice != 2 && userChoice != 3 && userChoice != 4 && userChoice != 5 && userChoice != 6 && userChoice != 9)
        {
            System.out.println("Invalid choice. Please try again.");
            System.out.println("1. Add a Book");
            System.out.println("2. Add an Audiobook");
            System.out.println("3. Add a DVD");
            System.out.println("4. Remove a Book");
            System.out.println("5. Remove an Audiobook");
            System.out.println("6. Display Catalog");
            System.out.println("9. Exit");
        }
        
    }
    }

    //declaring isbnExists method to check if the ISBN already exists in the bookList
    public static boolean isbnExists(int ISBN)
    {
        for (Book book : bookList)
        {
            if (book.getTheISBN() == ISBN)
            {
                return true;
            }
        }
        return false;
    }

    //declaring dvdCodeExists method to check if the DVD code already exists in the dvdList
    public static boolean dvdCodeExists(int dvdcode)
    {
        for (DVD dvd : dvdList)
        {
            if (dvd.getTheDvdCode() == dvdcode)
            {
                return true;
            }
        }
        return false;
    }

    //declaring addBook method to add a book to the catalog
    public static void addBook()
    {
        Scanner userInput = new Scanner (System.in);

        System.out.print("Enter the title of the book: ");
        String title = userInput.nextLine();

        System.out.print("Enter the price of the book: ");
        double price = userInput.nextDouble();
        userInput.nextLine(); // newline character

        System.out.print("Enter the author of the book: ");
        String author = userInput.nextLine();

        System.out.print("Enter the ISBN of the book: ");
        int ISBN = userInput.nextInt();
        userInput.nextLine(); // newline character

        //checking if the ISBN already exists in the bookList, if not add the book to the list
        if (!isbnExists(ISBN))
        {
            Book book = new Book (title, price, author, ISBN);
            bookList.add(book);
            System.out.println("Book added successfully!");
        }
        else
        {
            System.out.println("Duplicate ISBN found for book: " + title + ". Book not added.");
        }

        //saving book to the file
        bookList.add(new Book(title, price, author, ISBN));
        saveCatalog();
    }

    //declaring addAudioBook method to add an audiobook to the catalog
    public static void addAudioBook()
    {
        Scanner userInput = new Scanner (System.in);

        System.out.print("Enter the title of the audiobook: ");
        String title = userInput.nextLine();

        System.out.print("Enter the price of the audiobook: ");
        double price = userInput.nextDouble();
        userInput.nextLine(); // newline character

        System.out.print("Enter the author of the audiobook: ");
        String author = userInput.nextLine();

        System.out.print("Enter the ISBN of the audiobook: ");
        int ISBN = userInput.nextInt();
        userInput.nextLine(); // newline character

        System.out.print("Enter the running time of the audiobook: ");
        double runningTime = userInput.nextDouble();
        userInput.nextLine(); // newline character

        //checking if the ISBN already exists in the bookList, if not add the audiobook to the list
        if (!isbnExists(ISBN))
        {
            audioBook audiobook = new audioBook (title, price, author, ISBN, runningTime);
            bookList.add(audiobook);
            System.out.println("Audiobook added successfully!");
        }
        else
        {
            System.out.println("Duplicate ISBN found for audiobook: " + title + ". Audiobook not added.");
        }

        //saving audiobook to the file
        bookList.add(new audioBook(title, price, author, ISBN, runningTime));
        saveCatalog();
    }

    //declaring addDVD method to add a dvd to the catalog
    public static void addDVD()
    {
        Scanner userInput = new Scanner (System.in);

        System.out.print("Enter the title of the DVD: ");
        String title = userInput.nextLine();

        System.out.print("Enter the price of the DVD: ");
        double price = userInput.nextDouble();
        userInput.nextLine(); // newline character

        System.out.print("Enter the director of the DVD: ");
        String director = userInput.nextLine();

        System.out.print("Enter the year of the DVD: ");
        int year = userInput.nextInt();
        userInput.nextLine(); // newline character

        System.out.print("Enter the DVD code of the DVD: ");
        int dvdcode = userInput.nextInt();
        userInput.nextLine(); // newline character

        //checking if the DVD code already exists in the dvdList, if not add the dvd to the list
        if (!dvdCodeExists(dvdcode))
        {
            DVD dvd = new DVD (title, price, director, year, dvdcode);
            dvdList.add(dvd);
            System.out.println("DVD added successfully!");
        }
        else
        {
            System.out.println("Duplicate DVD code found for DVD: " + title + ". DVD not added.");
        }

        //saving dvd to the file
        dvdList.add(new DVD(title, price, director, year, dvdcode));
        saveCatalog();
    }

    //declaring removeBook method to remove a book from the catalog
    public static void removeBook()
    {
        Scanner userInput = new Scanner (System.in);

        System.out.print("Enter the ISBN of the book to remove: ");
        int ISBN = userInput.nextInt();
        userInput.nextLine(); // newline character

        //checking if the ISBN exists in the bookList, if it does, remove the book from the list
        if (isbnExists(ISBN))
        {
            for (int i = 0; i < bookList.size(); i++)
            {
                if (bookList.get(i).getTheISBN() == ISBN)
                {
                    bookList.remove(i);
                    System.out.println("Book removed successfully!");
                    return;
                }
            }
        }
        else
        {
            System.out.println("No book found with ISBN: " + ISBN + ". Book not removed.");
        }

        //removing the book from the file
        saveCatalog();
    }

    //declaring removeAudioBook method to remove an audiobook from the catalog
    public static void removeAudioBook()
    {
        Scanner userInput = new Scanner (System.in);

        System.out.print("Enter the ISBN of the audiobook to remove: ");
        int ISBN = userInput.nextInt();
        userInput.nextLine(); // newline character

        //checking if the ISBN exists in the bookList, if it does, remove the audiobook from the list
        if (isbnExists(ISBN))
        {
            for (int i = 0; i < bookList.size(); i++)
            {
                if (bookList.get(i) instanceof audioBook && bookList.get(i).getTheISBN() == ISBN)
                {
                    bookList.remove(i);
                    System.out.println("Audiobook removed successfully!");
                    return;
                }
            }
            System.out.println("No audiobook found with ISBN: " + ISBN + ". Audiobook not removed.");
        }
        else
        {
            System.out.println("No audiobook found with ISBN: " + ISBN + ". Audiobook not removed.");
        }
        saveCatalog();
    }

    //declaring displayCatalog method to display the catalog
    public static void displayCatalog()
    {
        System.out.println("Catalog Items:");

        //displaying books and audiobooks
        for (Book book : bookList)
        {
            System.out.println(book.toString());
            System.out.println();
        }

        //displaying dvds
        for (DVD dvd : dvdList)
        {
            System.out.println(dvd.toString());
            System.out.println();
        }
    }

    //declaring saveCatalog method to save the catalog to the file
    public static void saveCatalog()
    {
        try
        {
            PrintWriter writer = new PrintWriter (new FileWriter (fileName));

            //saving books and audiobooks
            for (Book book : bookList)
            {
                if (book instanceof audioBook)
                {
                    writer.println("Audiobook");
                    writer.println(book.getTheTitle() + "," + book.getTheAuthor() + "," + book.getThePrice() + "," + book.getTheISBN() + "," + ((audioBook) book).getTheRunningTime());
                }
                else
                {
                    writer.println("Book");
                    writer.println(book.getTheTitle() + "," + book.getTheAuthor() + "," + book.getThePrice() + "," + book.getTheISBN());
                }
            }

            //saving dvds
            for (DVD dvd : dvdList)
            {
                writer.println("DVD");
                writer.println(dvd.getTheTitle() + "," + dvd.getThePrice() + "," + dvd.getTheDirector() + "," + dvd.getTheYear() + "," + dvd.getTheDvdCode());
            }

            //close the writer
            writer.close();

            System.out.println("Catalog saved successfully to " + fileName);
        }
        catch (Exception e)
        {
            System.out.println("Error saving catalog to file: " + e.getMessage());
        }
    }

    


}